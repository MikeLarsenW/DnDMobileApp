
#include <iostream>
#include <limits>

using namespace std;

int Choice;

int main()
{

	

	do {
		cout << "Please choose a number 1 through 5" << endl
			<< "1 for Mountain Dew, 2 for Coca Cola, 3 for Lemonade, 4 for Dr. Pepper, and 5 for Water\n";
		cin >> Choice;
		switch (Choice)
		{
		case 1:

			cout << "Here is your Mountain Dew\n";
			break;

		case 2:

			cout << "Here is your Coke\n";
			break;

		case 3:

			cout << "Here is your Lemonade\n";
			break;

		case 4:

			cout << "Here is your Dr. Pepper\n";
			break;

		case 5:

			cout << "Here is your Water\n";
			break;

		default:
			cout << "Error, Sorry that choice was not valid, Here is your money back ";
			break;

		}
	}
		while (Choice < 1 || Choice>5);

		system("PAUSE");
		return 0;
	}


