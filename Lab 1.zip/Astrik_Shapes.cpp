
#include <iostream>
#include <limits>

using namespace std;



int main()
{
	int space;
		for (int i = 1; i <= 5; ++i)
		{
			for (int j = 1; j <= i; ++j)
			{
				cout << "*";
			}
			cout << "\n";
		}

		for (int i = 1, k = 0; i <= 5; ++i, k = 0)
		{
			for (space = 1; space <= 5-i; ++space)
			{
				cout << " ";
			}

			while (k !=i)
			{
				cout << "*";
				++k;
			}
			cout << endl;
		}

		for (int i = 1, k = 0; i <= 4; ++i, k = 0)
		{
			for (space = 1; space <= 4 - i; ++space)
			{
				cout << " ";
			}

			while (k !=2*i-1)
			{
				cout << "*";
				++k;
			}
			cout << endl;
		}

		for (int i = 1, k = 0; i <= 4; ++i, k = 0)
		{
			for (space = 1; space <= 4 - i; ++space)
			{
				cout << " ";
			}

			while (k != 2 * i - 1)
			{
				cout << "*";
				++k;
			}
			cout << endl;
		}

		for (int i = 3, k = 0; i >= 1; --i, k = 0)
		{
			for (space = 1; space <= 4 - i; ++space)
			{
				cout << " ";
			}

			while (k != 2 * i - 1)
			{
				cout << "*";
				++k;
			}
			cout << endl;
		}


		system("PAUSE");
		return 0;
	
}


